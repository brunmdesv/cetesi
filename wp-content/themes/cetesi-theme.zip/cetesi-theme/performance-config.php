<?php
/**
 * Configurações de Performance para o Tema CETESI
 * 
 * @package CETESI-Theme
 * @version 1.0.0
 */

// Prevenir acesso direto
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Configurações de Performance
 */
define('CETESI_PERFORMANCE_CONFIG', array(
    // Cache
    'enable_browser_cache' => true,
    'cache_duration' => 31536000, // 1 ano em segundos
    
    // Compressão
    'enable_gzip' => true,
    'enable_minification' => true,
    
    // Lazy Loading
    'enable_lazy_loading' => true,
    'lazy_loading_threshold' => 0.1,
    
    // Fontes
    'preload_fonts' => true,
    'font_display_swap' => true,
    
    // JavaScript
    'defer_non_critical_js' => true,
    'async_third_party_js' => true,
    
    // CSS
    'inline_critical_css' => true,
    'defer_non_critical_css' => true,
    
    // Imagens
    'enable_webp' => true,
    'image_quality' => 85,
    
    // CDN
    'enable_cdn' => false,
    'cdn_url' => '',
    
    // Otimizações específicas
    'remove_query_strings' => true,
    'disable_emojis' => true,
    'disable_embeds' => true,
    'disable_xmlrpc' => true,
    'disable_rsd' => true,
    'disable_wlwmanifest' => true,
    'disable_shortlink' => true,
));

/**
 * Headers de Cache para Performance
 */
function cetesi_set_performance_headers() {
    if (CETESI_PERFORMANCE_CONFIG['enable_browser_cache']) {
        // Cache para CSS e JS
        if (preg_match('/\.(css|js)$/', $_SERVER['REQUEST_URI'])) {
            header('Cache-Control: public, max-age=' . CETESI_PERFORMANCE_CONFIG['cache_duration']);
            header('Expires: ' . gmdate('D, d M Y H:i:s', time() + CETESI_PERFORMANCE_CONFIG['cache_duration']) . ' GMT');
        }
        
        // Cache para imagens
        if (preg_match('/\.(jpg|jpeg|png|gif|webp|svg|ico)$/', $_SERVER['REQUEST_URI'])) {
            header('Cache-Control: public, max-age=' . (CETESI_PERFORMANCE_CONFIG['cache_duration'] / 2));
            header('Expires: ' . gmdate('D, d M Y H:i:s', time() + (CETESI_PERFORMANCE_CONFIG['cache_duration'] / 2)) . ' GMT');
        }
    }
}
add_action('send_headers', 'cetesi_set_performance_headers');

/**
 * Otimizações de Segurança e Performance
 */
function cetesi_security_performance_optimizations() {
    // Remover informações do WordPress
    remove_action('wp_head', 'wp_generator');
    remove_action('wp_head', 'wlwmanifest_link');
    remove_action('wp_head', 'rsd_link');
    remove_action('wp_head', 'wp_shortlink_wp_head');
    
    // Desabilitar XML-RPC se configurado
    if (CETESI_PERFORMANCE_CONFIG['disable_xmlrpc']) {
        add_filter('xmlrpc_enabled', '__return_false');
    }
    
    // Desabilitar embeds se configurado
    if (CETESI_PERFORMANCE_CONFIG['disable_embeds']) {
        remove_action('wp_head', 'wp_oembed_add_discovery_links');
        remove_action('wp_head', 'wp_oembed_add_host_js');
    }
}
add_action('init', 'cetesi_security_performance_optimizations');

/**
 * Otimização de consultas de banco de dados
 */
function cetesi_optimize_database_queries() {
    // Limitar revisões de posts
    if (!defined('WP_POST_REVISIONS')) {
        define('WP_POST_REVISIONS', 3);
    }
    
    // Otimizar autosave
    if (!defined('AUTOSAVE_INTERVAL')) {
        define('AUTOSAVE_INTERVAL', 300); // 5 minutos
    }
    
    // Limitar trash
    if (!defined('EMPTY_TRASH_DAYS')) {
        define('EMPTY_TRASH_DAYS', 7);
    }
}
add_action('init', 'cetesi_optimize_database_queries');

/**
 * Minificação básica de HTML
 */
function cetesi_minify_html($buffer) {
    if (CETESI_PERFORMANCE_CONFIG['enable_minification'] && !is_admin()) {
        // Remover comentários HTML
        $buffer = preg_replace('/<!--(?!\s*(?:\[if [^\]]+]|<!|>))(?:(?!-->).)*-->/s', '', $buffer);
        
        // Remover espaços em branco desnecessários
        $buffer = preg_replace('/\s+/', ' ', $buffer);
        $buffer = preg_replace('/>\s+</', '><', $buffer);
        
        // Remover quebras de linha desnecessárias
        $buffer = str_replace(array("\r\n", "\r", "\n"), '', $buffer);
    }
    
    return $buffer;
}

// Aplicar minificação apenas em produção
if (!WP_DEBUG && !is_admin()) {
    add_action('template_redirect', function() {
        ob_start('cetesi_minify_html');
    });
}
